# KORX Studio — Offline Design Starter

This package contains:
- `website/`: offline-first design website/PWA
- `android-app/`: Android Studio project that loads the same editor from local app assets

## Website
For reliable offline use, deploy the `website` folder to any static HTTPS host once, then open it once in a supported browser and install it to your home screen. The service worker caches the app shell. Project data is stored in browser local storage on that device.

**PNG export note:** The editor expects a local `html2canvas.min.js` file. To keep the app fully offline, place a locally obtained copy of the html2canvas browser build in `website/html2canvas.min.js` and also in `android-app/app/src/main/assets/www/html2canvas.min.js`. If it is missing, the editor will tell you that PNG export is unavailable; save/open project still works. Do not rely on a CDN if you need offline operation.

## Android app
Open `android-app` in Android Studio and let Gradle sync. Build > Build APK(s). The project uses a native WebView and loads the editor from bundled assets, so the editor UI itself does not require internet. For sharing/installing on phones, build a signed APK in Android Studio.

## Current MVP features
Add text/headings, rectangles, circles, lines and photos; drag items; change text, colour, font size, font family, width, rotation, opacity and page background; starter templates; save/open one project locally.

This is an original starter inspired by common design-editor workflows, not a copy of Canva's proprietary code or assets. It is not yet feature-for-feature equivalent to Canva. Test exports and storage on your target phone before using it for important work.
